package com.example.balloonpopgame

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.MediaPlayer
import android.os.Bundle
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var balloonView: BalloonView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        balloonView = BalloonView(this)
        setContentView(balloonView)
    }

    override fun onResume() {
        super.onResume()
        balloonView.resume()
    }

    override fun onPause() {
        super.onPause()
        balloonView.pause()
    }

    inner class BalloonView(context: Context) : SurfaceView(context), Runnable {

        private val thread: Thread = Thread(this)
        private val popSoundEffect: MediaPlayer = MediaPlayer.create(context, R.raw.popsoundeffect)
        private val matrix = Matrix()
        private val surfaceHolder: SurfaceHolder = holder
        private var balloons: MutableList<Balloon> = mutableListOf()
        private var gameRunning = true
        private val backgroundBitmap = BitmapFactory.decodeResource(
            resources,
            R.drawable.gamebackground
        )

        init {
            surfaceHolder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) {
                    resetGame()
                    thread.start()
                }
                override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
                override fun surfaceDestroyed(holder: SurfaceHolder) {
                    gameRunning = false
                    thread.join()
                }
            })
        }

        private fun resetGame() {
            balloons.clear()
            val random = Random()
            val numBalloons = random.nextInt(7) + 6 // Random number between 6 and 12
            for (i in 0 until numBalloons) {
                balloons.add(Balloon(context, width, height))
            }
        }

        fun resume() {
            gameRunning = true
        }

        fun pause() {
            gameRunning = false
        }

        override fun run() {
            while (gameRunning) {
                if (surfaceHolder.surface.isValid) {
                    val canvas = surfaceHolder.lockCanvas()

                    // Scale the background image to cover the entire canvas
                    val scaleWidth = canvas.width.toFloat() / backgroundBitmap.width
                    val scaleHeight = canvas.height.toFloat() / backgroundBitmap.height
                    matrix.reset()
                    matrix.postScale(scaleWidth, scaleHeight)

                    // Draw the scaled background
                    canvas.drawBitmap(backgroundBitmap, matrix, null)

                    // Draw the balloons
                    for (balloon in balloons) {
                        balloon.draw(canvas)
                        if (balloon.isPopped) {
                            balloons.remove(balloon)
                            break
                        }
                    }

                    surfaceHolder.unlockCanvasAndPost(canvas)

                    if (balloons.isEmpty()) {
                        resetGame()
                    }
                }
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN) {
                val x = event.x
                val y = event.y

                for (balloon in balloons) {
                    if (balloon.isTouched(x, y)) {
                        balloon.pop()

                        // Play the pop sound effect
                        playPopSoundEffect()

                        break
                    }
                }
            }
            return true
        }

        private fun playPopSoundEffect() {
            popSoundEffect.start()
        }
    }

    inner class Balloon(
        private val context: Context,
        private val screenWidth: Int,
        private val screenHeight: Int
    ) {
        private val paint: Paint = Paint()
        private var x: Float
        private var y: Float
        private val balloonBitmap: Bitmap
        var isPopped: Boolean = false
            private set

        init {
            paint.color = Color.BLUE

            // Load the balloon image from resources
            balloonBitmap = BitmapFactory.decodeResource(
                context.resources,
                R.drawable.globopixel
            )

            // Adjust the balloon's initial position
            x = Random().nextInt(screenWidth - balloonBitmap.width).toFloat()
            y = Random().nextInt(screenHeight - balloonBitmap.height).toFloat()
        }

        fun draw(canvas: Canvas) {
            if (!isPopped) {
                canvas.drawBitmap(balloonBitmap, x, y, paint)
            }
        }

        fun isTouched(touchX: Float, touchY: Float): Boolean {
            return !isPopped && touchX >= x && touchX <= x + balloonBitmap.width &&
                    touchY >= y && touchY <= y + balloonBitmap.height
        }

        fun pop() {
            isPopped = true
        }
    }
}